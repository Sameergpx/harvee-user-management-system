package com.usermanagement;

import com.usermanagement.controller.AuthController;
import com.usermanagement.controller.UserController;
import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;

public class Main {
    private static final int PORT = 8080;
    private static AuthController authController = new AuthController();
    private static UserController userController = new UserController();

    public static void main(String[] args) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        // Auth Endpoints
        server.createContext("/api/auth/register", new APIHandler("POST", "register"));
        server.createContext("/api/auth/login", new APIHandler("POST", "login"));
        server.createContext("/api/auth/refresh", new APIHandler("POST", "refresh"));

        // User Endpoints (consolidated to single handler per path)
        server.createContext("/api/users", new APIHandler("MULTI", "users"));
        server.createContext("/api/users/search", new APIHandler("GET", "searchUsers"));

        // Static file handler for frontend
        server.createContext("/", new StaticFileHandler());

        server.setExecutor(null);
        server.start();
        System.out.println("✅ H2 Database initialized successfully!");
        System.out.println("Server started on port " + PORT);
        System.out.println("Open http://localhost:" + PORT + " in your browser");
        
        // Keep the server running
        try {
            while (true) {
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            server.stop(0);
        }
    }

    static class APIHandler implements HttpHandler {
        private String method;
        private String action;

        APIHandler(String method, String action) {
            this.method = method;
            this.action = action;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            // Add CORS headers
            exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
            exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type, Authorization");
            exchange.getResponseHeaders().add("Content-Type", "application/json");

            if ("OPTIONS".equals(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(200, 0);
                exchange.close();
                return;
            }

            String response = "";
            int statusCode = 200;

            try {
                String requestMethod = exchange.getRequestMethod();
                String requestURI = exchange.getRequestURI().getPath();
                String queryString = exchange.getRequestURI().getQuery();

                // Read request body
                InputStream is = exchange.getRequestBody();
                String body = new String(is.readAllBytes(), StandardCharsets.UTF_8);

                // Get Authorization header
                String authHeader = exchange.getRequestHeaders().getFirst("Authorization");
                String token = authHeader != null ? authHeader.replace("Bearer ", "") : "";

                if ("POST".equals(requestMethod)) {
                    if ("/api/auth/register".equals(requestURI)) {
                        response = authController.register(body);
                    } else if ("/api/auth/login".equals(requestURI)) {
                        response = authController.login(body);
                    } else if ("/api/auth/refresh".equals(requestURI)) {
                        response = authController.refreshToken(body);
                    }
                } else if ("GET".equals(requestMethod)) {
                    if ("/api/users".equals(requestURI)) {
                        response = userController.getAllUsers(token);
                    } else if (requestURI.startsWith("/api/users/search")) {
                        String keyword = queryString != null ? queryString.replace("keyword=", "") : "";
                        response = userController.searchUsers(keyword, token);
                    } else if (requestURI.startsWith("/api/users/")) {
                        String[] parts = requestURI.split("/");
                        if (parts.length > 3 && !parts[3].isEmpty()) {
                            int userId = Integer.parseInt(parts[3]);
                            response = userController.getUserById(userId, token);
                        }
                    }
                } else if ("PUT".equals(requestMethod)) {
                    if (requestURI.startsWith("/api/users/")) {
                        String[] parts = requestURI.split("/");
                        if (parts.length > 3 && !parts[3].isEmpty()) {
                            int userId = Integer.parseInt(parts[3]);
                            response = userController.updateUser(userId, body, token);
                        }
                    }
                } else if ("DELETE".equals(requestMethod)) {
                    if (requestURI.startsWith("/api/users/")) {
                        String[] parts = requestURI.split("/");
                        if (parts.length > 3 && !parts[3].isEmpty()) {
                            int userId = Integer.parseInt(parts[3]);
                            response = userController.deleteUser(userId, token);
                        }
                    }
                }

                if (response.isEmpty()) {
                    response = "{\"success\": false, \"message\": \"Endpoint not found\"}";
                    statusCode = 404;
                }
            } catch (Exception e) {
                response = "{\"success\": false, \"message\": \"Server error: " + e.getMessage() + "\"}";
                statusCode = 500;
            }

            exchange.sendResponseHeaders(statusCode, response.getBytes().length);
            OutputStream os = exchange.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            String path = exchange.getRequestURI().getPath();

            // Default to index.html
            if ("/".equals(path)) {
                path = "/index.html";
            }

            String filePath = "frontend" + path;
            File file = new File(filePath);

            if (file.exists() && file.isFile()) {
                String contentType = getContentType(filePath);
                exchange.getResponseHeaders().add("Content-Type", contentType);

                byte[] fileData = new byte[(int) file.length()];
                FileInputStream fis = new FileInputStream(file);
                fis.read(fileData);
                fis.close();

                exchange.sendResponseHeaders(200, fileData.length);
                OutputStream os = exchange.getResponseBody();
                os.write(fileData);
                os.close();
            } else {
                String response = "404 Not Found";
                exchange.sendResponseHeaders(404, response.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(response.getBytes());
                os.close();
            }
        }

        private String getContentType(String filePath) {
            if (filePath.endsWith(".html")) return "text/html";
            if (filePath.endsWith(".css")) return "text/css";
            if (filePath.endsWith(".js")) return "application/javascript";
            if (filePath.endsWith(".json")) return "application/json";
            if (filePath.endsWith(".png")) return "image/png";
            if (filePath.endsWith(".jpg")) return "image/jpeg";
            if (filePath.endsWith(".gif")) return "image/gif";
            return "text/plain";
        }
    }
}
