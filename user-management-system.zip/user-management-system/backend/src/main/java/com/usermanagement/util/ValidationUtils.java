package com.usermanagement.util;

import java.util.regex.Pattern;

public class ValidationUtils {
    
    // Email validation
    private static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@(.+)$";
    private static final Pattern EMAIL_PATTERN = Pattern.compile(EMAIL_REGEX);

    // Name validation (alphabets and spaces only, min 3 chars)
    public static boolean isValidName(String name) {
        if (name == null || name.trim().length() < 3) {
            return false;
        }
        return name.matches("^[a-zA-Z\\s]+$");
    }

    // Email validation
    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    // Phone validation (10-15 digits)
    public static boolean isValidPhone(String phone) {
        if (phone == null) {
            return false;
        }
        return phone.matches("^[0-9]{10,15}$");
    }

    // Password validation (min 6 chars with at least one number)
    public static boolean isValidPassword(String password) {
        if (password == null || password.length() < 6) {
            return false;
        }
        return password.matches(".*[0-9].*");
    }

    // Address validation (max 150 chars, optional)
    public static boolean isValidAddress(String address) {
        if (address == null || address.trim().isEmpty()) {
            return true; // Optional field
        }
        return address.length() <= 150;
    }

    // Pincode validation (4-10 digits)
    public static boolean isValidPincode(String pincode) {
        if (pincode == null) {
            return false;
        }
        return pincode.matches("^[0-9]{4,10}$");
    }

    // State validation (not empty)
    public static boolean isValidState(String state) {
        return state != null && !state.trim().isEmpty();
    }

    // City validation (not empty)
    public static boolean isValidCity(String city) {
        return city != null && !city.trim().isEmpty();
    }

    // Country validation (not empty)
    public static boolean isValidCountry(String country) {
        return country != null && !country.trim().isEmpty();
    }

    // File size validation (max 2MB)
    public static boolean isValidFileSize(long fileSize) {
        return fileSize <= 2097152; // 2MB in bytes
    }

    // File type validation (jpg/png only)
    public static boolean isValidFileType(String fileName) {
        if (fileName == null) {
            return false;
        }
        String lowerFileName = fileName.toLowerCase();
        return lowerFileName.endsWith(".jpg") || lowerFileName.endsWith(".jpeg") || 
               lowerFileName.endsWith(".png");
    }
}
