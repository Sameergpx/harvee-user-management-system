package com.usermanagement.service;

import com.usermanagement.model.User;
import com.usermanagement.dao.UserDAO;
import com.usermanagement.util.SecurityUtils;
import com.usermanagement.util.ValidationUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserService {
    private UserDAO userDAO = new UserDAO();

    // User Registration
    public Map<String, Object> registerUser(User user) {
        Map<String, Object> response = new HashMap<>();
        
        // Validate all fields
        if (!ValidationUtils.isValidName(user.getName())) {
            response.put("success", false);
            response.put("message", "Name must be at least 3 characters and contain only alphabets");
            return response;
        }

        if (!ValidationUtils.isValidEmail(user.getEmail())) {
            response.put("success", false);
            response.put("message", "Invalid email format");
            return response;
        }

        if (userDAO.emailExists(user.getEmail())) {
            response.put("success", false);
            response.put("message", "Email already exists");
            return response;
        }

        if (!ValidationUtils.isValidPhone(user.getPhone())) {
            response.put("success", false);
            response.put("message", "Phone must be 10-15 digits");
            return response;
        }

        if (!ValidationUtils.isValidPassword(user.getPassword())) {
            response.put("success", false);
            response.put("message", "Password must be at least 6 characters with at least one number");
            return response;
        }

        if (!ValidationUtils.isValidAddress(user.getAddress())) {
            response.put("success", false);
            response.put("message", "Address must not exceed 150 characters");
            return response;
        }

        if (!ValidationUtils.isValidState(user.getState())) {
            response.put("success", false);
            response.put("message", "State is required");
            return response;
        }

        if (!ValidationUtils.isValidCity(user.getCity())) {
            response.put("success", false);
            response.put("message", "City is required");
            return response;
        }

        if (!ValidationUtils.isValidCountry(user.getCountry())) {
            response.put("success", false);
            response.put("message", "Country is required");
            return response;
        }

        if (!ValidationUtils.isValidPincode(user.getPincode())) {
            response.put("success", false);
            response.put("message", "Pincode must be 4-10 digits");
            return response;
        }

        // Hash password
        user.setPassword(SecurityUtils.hashPassword(user.getPassword()));
        user.setRole("user");

        // Save to database
        if (userDAO.createUser(user)) {
            response.put("success", true);
            response.put("message", "User registered successfully");
            response.put("userId", user.getId());
        } else {
            response.put("success", false);
            response.put("message", "Error registering user");
        }

        return response;
    }

    // User Login
    public Map<String, Object> loginUser(String emailOrPhone, String password) {
        Map<String, Object> response = new HashMap<>();

        User user = null;
        if (ValidationUtils.isValidEmail(emailOrPhone)) {
            user = userDAO.getUserByEmail(emailOrPhone);
        }

        if (user == null) {
            response.put("success", false);
            response.put("message", "User not found");
            return response;
        }

        if (!SecurityUtils.verifyPassword(password, user.getPassword())) {
            response.put("success", false);
            response.put("message", "Invalid password");
            return response;
        }

        // Generate tokens
        String accessToken = SecurityUtils.generateAccessToken(user.getId(), user.getEmail(), user.getRole());
        String refreshToken = SecurityUtils.generateRefreshToken(user.getId(), user.getEmail());

        response.put("success", true);
        response.put("message", "Login successful");
        response.put("userId", user.getId());
        response.put("email", user.getEmail());
        response.put("name", user.getName());
        response.put("role", user.getRole());
        response.put("accessToken", accessToken);
        response.put("refreshToken", refreshToken);

        return response;
    }

    // Get User by ID
    public User getUserById(int id) {
        return userDAO.getUserById(id);
    }

    // Get All Users (Admin only)
    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }

    // Update User
    public Map<String, Object> updateUser(User user) {
        Map<String, Object> response = new HashMap<>();

        if (!ValidationUtils.isValidName(user.getName())) {
            response.put("success", false);
            response.put("message", "Invalid name");
            return response;
        }

        if (!ValidationUtils.isValidPhone(user.getPhone())) {
            response.put("success", false);
            response.put("message", "Invalid phone");
            return response;
        }

        if (!ValidationUtils.isValidState(user.getState())) {
            response.put("success", false);
            response.put("message", "State is required");
            return response;
        }

        if (!ValidationUtils.isValidCity(user.getCity())) {
            response.put("success", false);
            response.put("message", "City is required");
            return response;
        }

        if (!ValidationUtils.isValidCountry(user.getCountry())) {
            response.put("success", false);
            response.put("message", "Country is required");
            return response;
        }

        if (!ValidationUtils.isValidPincode(user.getPincode())) {
            response.put("success", false);
            response.put("message", "Invalid pincode");
            return response;
        }

        if (userDAO.updateUser(user)) {
            response.put("success", true);
            response.put("message", "User updated successfully");
        } else {
            response.put("success", false);
            response.put("message", "Error updating user");
        }

        return response;
    }

    // Delete User (Admin only)
    public Map<String, Object> deleteUser(int id) {
        Map<String, Object> response = new HashMap<>();

        if (userDAO.deleteUser(id)) {
            response.put("success", true);
            response.put("message", "User deleted successfully");
        } else {
            response.put("success", false);
            response.put("message", "Error deleting user");
        }

        return response;
    }

    // Search Users
    public List<User> searchUsers(String keyword) {
        return userDAO.searchUsers(keyword);
    }
}
