package com.usermanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
    private static final String DRIVER = "org.h2.Driver";
    private static final String DB_URL = "jdbc:h2:./data/user_management_db;MODE=MySQL;AUTO_SERVER=TRUE";
    private static final String DB_USER = "sa";
    private static final String DB_PASSWORD = "";
    private static boolean initialized = false;

    static {
        try {
            Class.forName(DRIVER);
            initializeDatabase();
        } catch (ClassNotFoundException e) {
            System.err.println("H2 Driver not found: " + e.getMessage());
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.println("Database initialization error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static synchronized void initializeDatabase() throws SQLException {
        if (initialized) return;
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {
            
            // Create users table if it doesn't exist
            stmt.execute("CREATE TABLE IF NOT EXISTS users (" +
                "id INT AUTO_INCREMENT PRIMARY KEY," +
                "name VARCHAR(100) NOT NULL," +
                "email VARCHAR(100) UNIQUE NOT NULL," +
                "phone VARCHAR(15) NOT NULL," +
                "password VARCHAR(255) NOT NULL," +
                "profile_image VARCHAR(255)," +
                "address VARCHAR(150)," +
                "state VARCHAR(50) NOT NULL," +
                "city VARCHAR(50) NOT NULL," +
                "country VARCHAR(50) NOT NULL," +
                "pincode VARCHAR(10) NOT NULL," +
                "role ENUM('user', 'admin') DEFAULT 'user'," +
                "created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP," +
                "updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP" +
            ")");
            
            // Insert demo admin user if not exists
            stmt.execute("MERGE INTO users (name, email, phone, password, state, city, country, pincode, role) " +
                "KEY (email) VALUES ('Admin User', 'admin@test.com', '9876543210', " +
                "'$2a$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lm', " +
                "'Delhi', 'New Delhi', 'India', '110001', 'admin')");
            
            initialized = true;
            System.out.println("✅ H2 Database initialized successfully!");
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            System.err.println("Database connection error: " + e.getMessage());
            throw e;
        }
    }

    public static void closeConnection(Connection conn) {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: " + e.getMessage());
        }
    }
}
