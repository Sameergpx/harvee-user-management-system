package com.usermanagement.controller;

import com.usermanagement.model.User;
import com.usermanagement.service.UserService;
import com.usermanagement.util.SecurityUtils;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.auth0.jwt.exceptions.JWTVerificationException;

import java.util.Map;
import java.util.List;
import java.util.HashMap;

public class UserController {
    private UserService userService = new UserService();
    private Gson gson = new Gson();

    public String getAllUsers(String token) {
        try {
            // Verify token
            String role = SecurityUtils.getRoleFromToken(token);
            if (!"admin".equals(role)) {
                Map<String, Object> error = new HashMap<>();
                error.put("success", false);
                error.put("message", "Unauthorized. Admin access required.");
                return gson.toJson(error);
            }

            List<User> users = userService.getAllUsers();
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", users);
            return gson.toJson(response);
        } catch (JWTVerificationException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Invalid token");
            return gson.toJson(error);
        }
    }

    public String getUserById(int id, String token) {
        try {
            // Verify token
            SecurityUtils.verifyToken(token);

            User user = userService.getUserById(id);
            if (user != null) {
                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("data", user);
                return gson.toJson(response);
            } else {
                Map<String, Object> error = new HashMap<>();
                error.put("success", false);
                error.put("message", "User not found");
                return gson.toJson(error);
            }
        } catch (JWTVerificationException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Invalid token");
            return gson.toJson(error);
        }
    }

    public String updateUser(int id, String jsonBody, String token) {
        try {
            // Verify token
            SecurityUtils.verifyToken(token);

            JsonObject json = JsonParser.parseString(jsonBody).getAsJsonObject();
            
            User user = new User();
            user.setId(id);
            user.setName(json.get("name").getAsString());
            user.setPhone(json.get("phone").getAsString());
            user.setAddress(json.has("address") ? json.get("address").getAsString() : "");
            user.setState(json.get("state").getAsString());
            user.setCity(json.get("city").getAsString());
            user.setCountry(json.get("country").getAsString());
            user.setPincode(json.get("pincode").getAsString());
            user.setProfileImage(json.has("profileImage") ? json.get("profileImage").getAsString() : null);

            Map<String, Object> response = userService.updateUser(user);
            return gson.toJson(response);
        } catch (JWTVerificationException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Invalid token");
            return gson.toJson(error);
        } catch (Exception e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Error: " + e.getMessage());
            return gson.toJson(error);
        }
    }

    public String deleteUser(int id, String token) {
        try {
            // Verify token and check if admin
            String role = SecurityUtils.getRoleFromToken(token);
            if (!"admin".equals(role)) {
                Map<String, Object> error = new HashMap<>();
                error.put("success", false);
                error.put("message", "Unauthorized. Admin access required.");
                return gson.toJson(error);
            }

            Map<String, Object> response = userService.deleteUser(id);
            return gson.toJson(response);
        } catch (JWTVerificationException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Invalid token");
            return gson.toJson(error);
        }
    }

    public String searchUsers(String keyword, String token) {
        try {
            // Verify token
            String role = SecurityUtils.getRoleFromToken(token);
            if (!"admin".equals(role)) {
                Map<String, Object> error = new HashMap<>();
                error.put("success", false);
                error.put("message", "Unauthorized. Admin access required.");
                return gson.toJson(error);
            }

            List<User> users = userService.searchUsers(keyword);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("data", users);
            return gson.toJson(response);
        } catch (JWTVerificationException e) {
            Map<String, Object> error = new HashMap<>();
            error.put("success", false);
            error.put("message", "Invalid token");
            return gson.toJson(error);
        }
    }
}
