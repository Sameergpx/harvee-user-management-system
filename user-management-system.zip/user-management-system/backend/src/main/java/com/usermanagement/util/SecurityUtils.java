package com.usermanagement.util;

import org.mindrot.jbcrypt.BCrypt;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import java.util.Date;

public class SecurityUtils {
    private static final String SECRET_KEY = "your-secret-key-change-this-in-production";
    private static final long ACCESS_TOKEN_EXPIRY = 3600000; // 1 hour
    private static final long REFRESH_TOKEN_EXPIRY = 604800000; // 7 days

    // Password Hashing
    public static String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    public static boolean verifyPassword(String password, String hash) {
        return BCrypt.checkpw(password, hash);
    }

    // Access Token Generation
    public static String generateAccessToken(int userId, String email, String role) {
        return JWT.create()
                .withSubject(String.valueOf(userId))
                .withClaim("email", email)
                .withClaim("role", role)
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + ACCESS_TOKEN_EXPIRY))
                .sign(Algorithm.HMAC256(SECRET_KEY));
    }

    // Refresh Token Generation
    public static String generateRefreshToken(int userId, String email) {
        return JWT.create()
                .withSubject(String.valueOf(userId))
                .withClaim("email", email)
                .withIssuedAt(new Date())
                .withExpiresAt(new Date(System.currentTimeMillis() + REFRESH_TOKEN_EXPIRY))
                .sign(Algorithm.HMAC256(SECRET_KEY));
    }

    // Token Verification
    public static DecodedJWT verifyToken(String token) throws JWTVerificationException {
        return JWT.require(Algorithm.HMAC256(SECRET_KEY))
                .build()
                .verify(token);
    }

    // Extract User ID from Token
    public static int getUserIdFromToken(String token) throws JWTVerificationException {
        DecodedJWT jwt = verifyToken(token);
        return Integer.parseInt(jwt.getSubject());
    }

    // Extract Role from Token
    public static String getRoleFromToken(String token) throws JWTVerificationException {
        DecodedJWT jwt = verifyToken(token);
        return jwt.getClaim("role").asString();
    }

    // Extract Email from Token
    public static String getEmailFromToken(String token) throws JWTVerificationException {
        DecodedJWT jwt = verifyToken(token);
        return jwt.getClaim("email").asString();
    }
}
