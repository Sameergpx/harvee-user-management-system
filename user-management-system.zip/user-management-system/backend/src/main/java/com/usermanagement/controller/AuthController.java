package com.usermanagement.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.usermanagement.model.User;
import com.usermanagement.service.UserService;
import com.usermanagement.util.SecurityUtils;
import java.util.Map;

public class AuthController {
    private UserService userService = new UserService();
    private Gson gson = new Gson();

    // Register new user
    public String register(String jsonBody) {
        try {
            JsonObject request = JsonParser.parseString(jsonBody).getAsJsonObject();
            
            String name = request.get("name").getAsString();
            String email = request.get("email").getAsString();
            String phone = request.get("phone").getAsString();
            String password = request.get("password").getAsString();
            String address = request.has("address") ? request.get("address").getAsString() : "";
            String state = request.get("state").getAsString();
            String city = request.get("city").getAsString();
            String country = request.get("country").getAsString();
            String pincode = request.get("pincode").getAsString();

            // Create User object
            User user = new User();
            user.setName(name);
            user.setEmail(email);
            user.setPhone(phone);
            user.setPassword(password);
            user.setAddress(address);
            user.setState(state);
            user.setCity(city);
            user.setCountry(country);
            user.setPincode(pincode);
            user.setRole("user");

            // Call service
            Map<String, Object> response = userService.registerUser(user);
            return gson.toJson(response);
        } catch (Exception e) {
            return gson.toJson(new java.util.HashMap<String, Object>() {{
                put("success", false);
                put("message", "Registration failed: " + e.getMessage());
            }});
        }
    }

    // Login user
    public String login(String jsonBody) {
        try {
            JsonObject request = JsonParser.parseString(jsonBody).getAsJsonObject();
            
            String email = request.get("email").getAsString();
            String password = request.get("password").getAsString();

            // Call service
            Map<String, Object> response = userService.loginUser(email, password);
            return gson.toJson(response);
        } catch (Exception e) {
            return gson.toJson(new java.util.HashMap<String, Object>() {{
                put("success", false);
                put("message", "Login failed: " + e.getMessage());
            }});
        }
    }

    // Refresh token
    public String refreshToken(String jsonBody) {
        try {
            JsonObject request = JsonParser.parseString(jsonBody).getAsJsonObject();
            String refreshToken = request.get("refreshToken").getAsString();

            // Verify refresh token
            int userId = SecurityUtils.getUserIdFromToken(refreshToken);
            String email = SecurityUtils.getEmailFromToken(refreshToken);
            String role = SecurityUtils.getRoleFromToken(refreshToken);

            // Generate new access token
            String newAccessToken = SecurityUtils.generateAccessToken(userId, email, role);

            Map<String, Object> response = new java.util.HashMap<>();
            response.put("success", true);
            response.put("accessToken", newAccessToken);
            response.put("refreshToken", refreshToken);
            return gson.toJson(response);
        } catch (Exception e) {
            return gson.toJson(new java.util.HashMap<String, Object>() {{
                put("success", false);
                put("message", "Token refresh failed: " + e.getMessage());
            }});
        }
    }
}
