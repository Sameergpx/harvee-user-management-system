const API_URL = 'http://localhost:8080/api';

document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // Clear previous alerts
    document.getElementById('errorAlert').classList.add('d-none');
    document.getElementById('successAlert').classList.add('d-none');
    
    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const password = document.getElementById('password').value;
    const address = document.getElementById('address').value.trim();
    const state = document.getElementById('state').value.trim();
    const city = document.getElementById('city').value.trim();
    const country = document.getElementById('country').value.trim();
    const pincode = document.getElementById('pincode').value.trim();
    
    // Validate fields
    if (!validateForm(name, email, phone, password, address, state, city, country, pincode)) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/auth/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                name,
                email,
                phone,
                password,
                address,
                state,
                city,
                country,
                pincode
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSuccess('Registration successful! Redirecting to login...');
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        } else {
            showError(data.message || 'Registration failed');
        }
    } catch (error) {
        console.error('Error:', error);
        showError('An error occurred: ' + error.message);
    }
});

function validateForm(name, email, phone, password, address, state, city, country, pincode) {
    let isValid = true;
    
    // Clear previous errors
    document.querySelectorAll('.text-danger').forEach(el => el.textContent = '');
    
    // Name validation
    if (name.length < 3) {
        document.getElementById('nameError').textContent = 'Name must be at least 3 characters';
        isValid = false;
    } else if (!/^[a-zA-Z\s]+$/.test(name)) {
        document.getElementById('nameError').textContent = 'Name must contain only alphabets';
        isValid = false;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        document.getElementById('emailError').textContent = 'Invalid email format';
        isValid = false;
    }
    
    // Phone validation
    if (!/^\d{10,15}$/.test(phone)) {
        document.getElementById('phoneError').textContent = 'Phone must be 10-15 digits';
        isValid = false;
    }
    
    // Password validation
    if (password.length < 6) {
        document.getElementById('passwordError').textContent = 'Password must be at least 6 characters';
        isValid = false;
    } else if (!/\d/.test(password)) {
        document.getElementById('passwordError').textContent = 'Password must contain at least one number';
        isValid = false;
    }
    
    // Address validation (optional but max 150 chars if provided)
    if (address.length > 150) {
        document.getElementById('addressError').textContent = 'Address must not exceed 150 characters';
        isValid = false;
    }
    
    // State validation
    if (!state) {
        document.getElementById('stateError').textContent = 'State is required';
        isValid = false;
    }
    
    // City validation
    if (!city) {
        document.getElementById('cityError').textContent = 'City is required';
        isValid = false;
    }
    
    // Country validation
    if (!country) {
        document.getElementById('countryError').textContent = 'Country is required';
        isValid = false;
    }
    
    // Pincode validation
    if (!/^\d{4,10}$/.test(pincode)) {
        document.getElementById('pincodeError').textContent = 'Pincode must be 4-10 digits';
        isValid = false;
    }
    
    return isValid;
}

function showError(message) {
    const alert = document.getElementById('errorAlert');
    alert.textContent = message;
    alert.classList.remove('d-none');
}

function showSuccess(message) {
    const alert = document.getElementById('successAlert');
    alert.textContent = message;
    alert.classList.remove('d-none');
}
