const API_URL = 'http://localhost:8080/api';
let allUsers = [];
let currentEditUser = null;

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    checkAuthAndInit();
});

function checkAuthAndInit() {
    const token = localStorage.getItem('accessToken');
    const userRole = localStorage.getItem('userRole');
    const userName = localStorage.getItem('userName');
    
    if (!token || userRole !== 'admin') {
        window.location.href = 'login.html';
        return;
    }
    
    document.getElementById('userName').textContent = userName;
    
    // Setup sidebar navigation
    setupNavigation();
    
    // Load initial data
    loadDashboardStats();
    loadAllUsers();
}

function setupNavigation() {
    document.querySelectorAll('.list-group-item').forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const section = item.dataset.section;
            
            // Hide all sections
            document.querySelectorAll('.content-section').forEach(s => {
                s.classList.add('d-none');
            });
            
            // Remove active class from all items
            document.querySelectorAll('.list-group-item').forEach(i => {
                i.classList.remove('active');
            });
            
            // Show selected section and set active
            if (section === 'dashboard') {
                document.getElementById('dashboardSection').classList.remove('d-none');
            } else if (section === 'users') {
                document.getElementById('usersSection').classList.remove('d-none');
            } else if (section === 'profile') {
                document.getElementById('profileSection').classList.remove('d-none');
                loadUserProfile();
            }
            
            item.classList.add('active');
        });
    });
}

async function loadDashboardStats() {
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const users = data.data || [];
            document.getElementById('totalUsers').textContent = users.length;
            document.getElementById('activeUsers').textContent = users.filter(u => u.role === 'user').length;
            document.getElementById('adminUsers').textContent = users.filter(u => u.role === 'admin').length;
        }
    } catch (error) {
        console.error('Error loading dashboard stats:', error);
    }
}

async function loadAllUsers() {
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            allUsers = data.data || [];
            displayUsers(allUsers);
        } else {
            showError(data.message);
        }
    } catch (error) {
        console.error('Error loading users:', error);
        showError('Error loading users');
    }
}

function displayUsers(users) {
    const tbody = document.getElementById('usersTable');
    
    if (!users || users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="8" class="text-center">No users found</td></tr>';
        return;
    }
    
    tbody.innerHTML = users.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.phone}</td>
            <td>${user.state}</td>
            <td>${user.city}</td>
            <td><span class="badge ${user.role === 'admin' ? 'badge-admin' : 'badge-user'}">${user.role.toUpperCase()}</span></td>
            <td>
                <div class="action-buttons">
                    <button class="btn btn-sm btn-info" onclick="viewUser(${user.id})">View</button>
                    <button class="btn btn-sm btn-warning" onclick="editUserModal(${user.id})">Edit</button>
                    <button class="btn btn-sm btn-danger" onclick="deleteUserConfirm(${user.id})">Delete</button>
                </div>
            </td>
        </tr>
    `).join('');
}

async function searchUsers() {
    const keyword = document.getElementById('searchInput').value.trim();
    
    if (!keyword) {
        loadAllUsers();
        return;
    }
    
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users/search?keyword=${encodeURIComponent(keyword)}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayUsers(data.data || []);
        } else {
            showError(data.message);
        }
    } catch (error) {
        console.error('Error searching users:', error);
        showError('Error searching users');
    }
}

async function viewUser(userId) {
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users/${userId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const user = data.data;
            const detailsHtml = `
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Name:</strong> ${user.name}</p>
                        <p><strong>Email:</strong> ${user.email}</p>
                        <p><strong>Phone:</strong> ${user.phone}</p>
                        <p><strong>Role:</strong> <span class="badge ${user.role === 'admin' ? 'badge-admin' : 'badge-user'}">${user.role.toUpperCase()}</span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Address:</strong> ${user.address || 'N/A'}</p>
                        <p><strong>State:</strong> ${user.state}</p>
                        <p><strong>City:</strong> ${user.city}</p>
                        <p><strong>Country:</strong> ${user.country}</p>
                        <p><strong>Pincode:</strong> ${user.pincode}</p>
                    </div>
                </div>
                <hr>
                <p><strong>Created:</strong> ${new Date(user.createdAt).toLocaleString()}</p>
                <p><strong>Updated:</strong> ${new Date(user.updatedAt).toLocaleString()}</p>
            `;
            
            document.getElementById('userDetailsContent').innerHTML = detailsHtml;
            const modal = new bootstrap.Modal(document.getElementById('viewUserModal'));
            modal.show();
        }
    } catch (error) {
        console.error('Error fetching user details:', error);
        showError('Error fetching user details');
    }
}

async function editUserModal(userId) {
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users/${userId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            currentEditUser = data.data;
            document.getElementById('editUserId').value = currentEditUser.id;
            document.getElementById('editName').value = currentEditUser.name;
            document.getElementById('editPhone').value = currentEditUser.phone;
            document.getElementById('editAddress').value = currentEditUser.address || '';
            document.getElementById('editState').value = currentEditUser.state;
            document.getElementById('editCity').value = currentEditUser.city;
            document.getElementById('editCountry').value = currentEditUser.country;
            document.getElementById('editPincode').value = currentEditUser.pincode;
            
            const modal = new bootstrap.Modal(document.getElementById('editUserModal'));
            modal.show();
        }
    } catch (error) {
        console.error('Error fetching user for edit:', error);
        showError('Error fetching user details');
    }
}

async function updateUser() {
    const userId = document.getElementById('editUserId').value;
    const name = document.getElementById('editName').value.trim();
    const phone = document.getElementById('editPhone').value.trim();
    const address = document.getElementById('editAddress').value.trim();
    const state = document.getElementById('editState').value.trim();
    const city = document.getElementById('editCity').value.trim();
    const country = document.getElementById('editCountry').value.trim();
    const pincode = document.getElementById('editPincode').value.trim();
    
    if (!name || !phone || !state || !city || !country || !pincode) {
        showError('Please fill all required fields');
        return;
    }
    
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users/${userId}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                name,
                phone,
                address,
                state,
                city,
                country,
                pincode
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSuccess('User updated successfully');
            bootstrap.Modal.getInstance(document.getElementById('editUserModal')).hide();
            loadAllUsers();
        } else {
            showError(data.message);
        }
    } catch (error) {
        console.error('Error updating user:', error);
        showError('Error updating user');
    }
}

async function deleteUserConfirm(userId) {
    if (!confirm('Are you sure you want to delete this user?')) {
        return;
    }
    
    try {
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users/${userId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSuccess('User deleted successfully');
            loadAllUsers();
        } else {
            showError(data.message);
        }
    } catch (error) {
        console.error('Error deleting user:', error);
        showError('Error deleting user');
    }
}

async function loadUserProfile() {
    try {
        const userId = localStorage.getItem('userId');
        const token = localStorage.getItem('accessToken');
        const response = await fetch(`${API_URL}/users/${userId}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const user = data.data;
            const profileHtml = `
                <div class="row">
                    <div class="col-md-4 text-center">
                        ${user.profileImage ? `<img src="${user.profileImage}" alt="Profile" class="profile-image">` : '<p class="text-muted">No profile image</p>'}
                    </div>
                    <div class="col-md-8">
                        <table class="table">
                            <tr>
                                <th>Name</th>
                                <td>${user.name}</td>
                            </tr>
                            <tr>
                                <th>Email</th>
                                <td>${user.email}</td>
                            </tr>
                            <tr>
                                <th>Phone</th>
                                <td>${user.phone}</td>
                            </tr>
                            <tr>
                                <th>Role</th>
                                <td><span class="badge ${user.role === 'admin' ? 'badge-admin' : 'badge-user'}">${user.role.toUpperCase()}</span></td>
                            </tr>
                            <tr>
                                <th>Address</th>
                                <td>${user.address || 'N/A'}</td>
                            </tr>
                            <tr>
                                <th>State</th>
                                <td>${user.state}</td>
                            </tr>
                            <tr>
                                <th>City</th>
                                <td>${user.city}</td>
                            </tr>
                            <tr>
                                <th>Country</th>
                                <td>${user.country}</td>
                            </tr>
                            <tr>
                                <th>Pincode</th>
                                <td>${user.pincode}</td>
                            </tr>
                        </table>
                    </div>
                </div>
            `;
            
            document.getElementById('profileContent').innerHTML = profileHtml;
        }
    } catch (error) {
        console.error('Error loading profile:', error);
        showError('Error loading profile');
    }
}

function logout() {
    localStorage.clear();
    window.location.href = 'login.html';
}

function showError(message) {
    const alert = document.getElementById('errorAlert');
    alert.textContent = message;
    alert.classList.remove('d-none');
    setTimeout(() => {
        alert.classList.add('d-none');
    }, 5000);
}

function showSuccess(message) {
    const alert = document.getElementById('successAlert');
    alert.textContent = message;
    alert.classList.remove('d-none');
    setTimeout(() => {
        alert.classList.add('d-none');
    }, 5000);
}
