# User Management System - ER Diagram & Database Documentation

## Entity Relationship Diagram (ER Diagram)

```
┌─────────────────────────────────────┐
│           USERS                     │
├─────────────────────────────────────┤
│ PK │ id             │ INT           │
│    │ name           │ VARCHAR(100)  │
│ UQ │ email          │ VARCHAR(100)  │
│    │ phone          │ VARCHAR(15)   │
│    │ password       │ VARCHAR(255)  │
│    │ profile_image  │ VARCHAR(255)  │
│    │ address        │ VARCHAR(150)  │
│    │ state          │ VARCHAR(50)   │
│    │ city           │ VARCHAR(50)   │
│    │ country        │ VARCHAR(50)   │
│    │ pincode        │ VARCHAR(10)   │
│    │ role           │ ENUM          │
│ TS │ created_at     │ TIMESTAMP     │
│ TS │ updated_at     │ TIMESTAMP     │
└─────────────────────────────────────┘

PK  = Primary Key
UQ  = Unique Constraint
TS  = Timestamp
```

## Database Schema Details

### Table: `users`

#### Column Specifications

| Column | Type | Constraints | Description |
|--------|------|-------------|-------------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Unique identifier for each user |
| name | VARCHAR(100) | NOT NULL | User's full name (3-100 chars, alphabets & spaces) |
| email | VARCHAR(100) | NOT NULL, UNIQUE | User's email address (must be unique) |
| phone | VARCHAR(15) | NOT NULL | Phone number (10-15 digits) |
| password | VARCHAR(255) | NOT NULL | Hashed password using BCrypt |
| profile_image | VARCHAR(255) | NULL | Path/URL to profile image |
| address | VARCHAR(150) | NULL | User's address (optional, max 150 chars) |
| state | VARCHAR(50) | NOT NULL | User's state |
| city | VARCHAR(50) | NOT NULL | User's city |
| country | VARCHAR(50) | NOT NULL | User's country |
| pincode | VARCHAR(10) | NOT NULL | Postal code (4-10 digits) |
| role | ENUM('user','admin') | DEFAULT 'user' | User role |
| created_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Account creation timestamp |
| updated_at | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP ON UPDATE | Last update timestamp |

#### SQL Definition

```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    profile_image VARCHAR(255),
    address VARCHAR(150),
    state VARCHAR(50) NOT NULL,
    city VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL,
    pincode VARCHAR(10) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_state (state),
    INDEX idx_city (city),
    INDEX idx_role (role)
);
```

### Indexes

| Index Name | Columns | Type | Purpose |
|------------|---------|------|---------|
| PRIMARY | id | BTREE | Primary key |
| email | email | BTREE | Fast email lookup |
| idx_state | state | BTREE | Fast state filtering |
| idx_city | city | BTREE | Fast city filtering |
| idx_role | role | BTREE | Fast role-based queries |

### Constraints

1. **PRIMARY KEY (id)** - Ensures uniqueness of each user record
2. **UNIQUE (email)** - Prevents duplicate email addresses
3. **NOT NULL (name, email, phone, password, state, city, country, pincode)** - Required fields
4. **CHECK (role IN ('user', 'admin'))** - Validates role values
5. **CHECK (email LIKE '%@%.%')** - Optional: email format validation
6. **CHECK (LENGTH(phone) BETWEEN 10 AND 15)** - Phone length validation
7. **CHECK (LENGTH(pincode) BETWEEN 4 AND 10)** - Pincode validation

## Normalization Analysis

### Normal Form: 3NF (Third Normal Form)

#### First Normal Form (1NF)
✅ **Satisfied**
- All attributes contain atomic values
- No repeating groups
- Each column contains only one value per row

#### Second Normal Form (2NF)
✅ **Satisfied**
- All non-key attributes depend on the entire primary key
- No partial dependencies
- Since we have a single primary key (id), all attributes depend on it

#### Third Normal Form (3NF)
✅ **Satisfied**
- No transitive dependencies between non-key attributes
- All non-key attributes depend only on the primary key
- Well-designed table structure

## Data Type Justification

| Column | Type | Why |
|--------|------|-----|
| id | INT | Integer for efficient indexing and auto-increment |
| name | VARCHAR(100) | Variable length, max 100 chars sufficient |
| email | VARCHAR(100) | Email addresses up to 100 chars |
| phone | VARCHAR(15) | International phone numbers up to 15 digits |
| password | VARCHAR(255) | BCrypt hashes are typically 60+ chars, 255 is safe |
| profile_image | VARCHAR(255) | URL or file path storage |
| address | VARCHAR(150) | Requirement specified max 150 chars |
| state | VARCHAR(50) | State names fit well in 50 chars |
| city | VARCHAR(50) | City names fit well in 50 chars |
| country | VARCHAR(50) | Country names fit well in 50 chars |
| pincode | VARCHAR(10) | Postal codes 4-10 digits, stored as string for formatting |
| role | ENUM | Efficient storage (1-2 bytes) for 2 fixed values |
| created_at | TIMESTAMP | Automatic timestamp tracking |
| updated_at | TIMESTAMP | Automatic update tracking |

## Sample Queries

### Create User
```sql
INSERT INTO users (name, email, phone, password, address, state, city, country, pincode, role)
VALUES ('John Doe', 'john@example.com', '9876543210', 'hashed_password', '123 Main St', 'CA', 'LA', 'USA', '90001', 'user');
```

### Read User
```sql
SELECT * FROM users WHERE email = 'john@example.com';
SELECT * FROM users WHERE id = 1;
```

### Read All Users
```sql
SELECT id, name, email, phone, state, city, role FROM users ORDER BY created_at DESC;
```

### Update User
```sql
UPDATE users
SET name = 'Jane Doe', state = 'NY'
WHERE id = 1;
```

### Delete User
```sql
DELETE FROM users WHERE id = 1;
```

### Search Users
```sql
SELECT * FROM users
WHERE name LIKE '%john%' 
   OR email LIKE '%john%'
   OR state LIKE '%california%'
   OR city LIKE '%los%'
ORDER BY created_at DESC;
```

### Get User Count by Role
```sql
SELECT role, COUNT(*) as count FROM users GROUP BY role;
```

### Get Users by State
```sql
SELECT * FROM users WHERE state = 'California' ORDER BY name;
```

## Performance Optimization

### Index Strategy
- **Email Index**: Enables fast lookups by email during login
- **State/City Index**: Enables fast filtering in search operations
- **Role Index**: Enables fast role-based access control queries

### Query Optimization Tips

1. **Always use indexes for WHERE clauses**
   ```sql
   -- Good (uses email index)
   SELECT * FROM users WHERE email = 'test@example.com';
   
   -- Avoid (full table scan)
   SELECT * FROM users WHERE PASSWORD = 'hash';
   ```

2. **Use LIMIT for pagination**
   ```sql
   SELECT * FROM users LIMIT 10 OFFSET 0;
   ```

3. **Avoid wildcard at start**
   ```sql
   -- Good (uses index)
   SELECT * FROM users WHERE name LIKE 'John%';
   
   -- Avoid (full table scan)
   SELECT * FROM users WHERE name LIKE '%John%';
   ```

## Backup & Recovery

### Backup Strategy
```bash
# Full database backup
mysqldump -u root -p user_management_db > backup.sql

# Backup specific table
mysqldump -u root -p user_management_db users > users_backup.sql
```

### Restore Strategy
```bash
# Restore full database
mysql -u root -p user_management_db < backup.sql

# Restore specific table
mysql -u root -p user_management_db < users_backup.sql
```

## Security Considerations

1. **Password Hashing**
   - Passwords stored as BCrypt hashes (60+ chars)
   - Never store plaintext passwords

2. **Email Uniqueness**
   - UNIQUE constraint prevents duplicate emails
   - Important for login functionality

3. **Sensitive Data**
   - Profile images stored separately
   - API never returns password hashes

4. **Audit Trail**
   - created_at: Track user account creation time
   - updated_at: Track profile modifications

5. **Role-Based Access**
   - ENUM constraint ensures valid roles
   - Admin operations require role verification

## Scalability Considerations

### For Large Datasets (100K+ users):

1. **Add Partitioning**
   ```sql
   ALTER TABLE users PARTITION BY RANGE (YEAR(created_at)) (
       PARTITION p2024 VALUES LESS THAN (2025),
       PARTITION p2025 VALUES LESS THAN (2026)
   );
   ```

2. **Archive Old Records**
   ```sql
   CREATE TABLE users_archive LIKE users;
   INSERT INTO users_archive SELECT * FROM users WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR);
   DELETE FROM users WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR);
   ```

3. **Read Replicas**
   - Set up MySQL replication for read-heavy operations

4. **Caching**
   - Implement Redis cache for frequently accessed users

## Future Enhancements

### Potential Schema Additions

1. **User Sessions Table**
   ```sql
   CREATE TABLE sessions (
       id INT AUTO_INCREMENT PRIMARY KEY,
       user_id INT NOT NULL,
       token VARCHAR(255) NOT NULL,
       expires_at TIMESTAMP,
       FOREIGN KEY (user_id) REFERENCES users(id)
   );
   ```

2. **Audit Log Table**
   ```sql
   CREATE TABLE audit_logs (
       id INT AUTO_INCREMENT PRIMARY KEY,
       user_id INT,
       action VARCHAR(100),
       timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
   );
   ```

3. **User Preferences Table**
   ```sql
   CREATE TABLE user_preferences (
       id INT AUTO_INCREMENT PRIMARY KEY,
       user_id INT NOT NULL,
       theme VARCHAR(20),
       notifications BOOLEAN,
       FOREIGN KEY (user_id) REFERENCES users(id)
   );
   ```

---

**Database Documentation Complete!**

For any questions about the database structure, refer to this document or the schema.sql file.
