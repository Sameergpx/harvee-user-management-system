# User Management System - API Documentation

## Base URL
```
http://localhost:8080
```

## Authentication
All protected endpoints require a JWT token in the Authorization header:
```
Authorization: Bearer YOUR_ACCESS_TOKEN
```

---

## 📌 Authentication Endpoints

### 1. Register User

**Endpoint:** `POST /api/auth/register`

**Description:** Create a new user account

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210",
  "password": "password123",
  "address": "123 Main Street",
  "state": "California",
  "city": "Los Angeles",
  "country": "USA",
  "pincode": "90001"
}
```

**Validation Rules:**
- `name`: 3-100 characters, alphabets and spaces only
- `email`: Valid email format, must be unique
- `phone`: 10-15 digits
- `password`: Minimum 6 characters with at least one number
- `address`: Optional, max 150 characters
- `state`: Required
- `city`: Required
- `country`: Required
- `pincode`: 4-10 digits

**Success Response (201):**
```json
{
  "success": true,
  "message": "User registered successfully",
  "userId": 5
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Email already exists"
}
```

**Error Messages:**
| Message | Reason |
|---------|--------|
| Name must be at least 3 characters and contain only alphabets | Invalid name |
| Invalid email format | Email not valid |
| Email already exists | Email duplicate |
| Phone must be 10-15 digits | Invalid phone |
| Password must be at least 6 characters with at least one number | Invalid password |
| Address must not exceed 150 characters | Address too long |
| State is required | Missing state |
| City is required | Missing city |
| Country is required | Missing country |
| Pincode must be 4-10 digits | Invalid pincode |

**cURL Example:**
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "9876543210",
    "password": "password123",
    "state": "California",
    "city": "Los Angeles",
    "country": "USA",
    "pincode": "90001"
  }'
```

---

### 2. Login User

**Endpoint:** `POST /api/auth/login`

**Description:** Authenticate user and receive tokens

**Request Body:**
```json
{
  "email": "john@example.com",
  "password": "password123"
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "Login successful",
  "userId": 5,
  "email": "john@example.com",
  "name": "John Doe",
  "role": "user",
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Invalid password"
}
```

**Error Messages:**
| Message | Reason |
|---------|--------|
| User not found | Email doesn't exist |
| Invalid password | Wrong password |

**Token Details:**
- **Access Token**: Expires in 1 hour, used for API requests
- **Refresh Token**: Expires in 7 days, used to get new access tokens

**cURL Example:**
```bash
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'
```

---

### 3. Refresh Token

**Endpoint:** `POST /api/auth/refresh`

**Description:** Get a new access token using refresh token

**Request Body:**
```json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Success Response (200):**
```json
{
  "success": true,
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Invalid refresh token"
}
```

**cURL Example:**
```bash
curl -X POST http://localhost:8080/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{
    "refreshToken": "YOUR_REFRESH_TOKEN"
  }'
```

---

## 👥 User Endpoints

### 4. Get All Users (Admin Only)

**Endpoint:** `GET /api/users`

**Description:** Retrieve list of all users

**Headers:**
```
Authorization: Bearer YOUR_ACCESS_TOKEN
Content-Type: application/json
```

**Query Parameters:** None

**Success Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "name": "Admin User",
      "email": "admin@test.com",
      "phone": "9876543210",
      "address": "Admin Address",
      "state": "Delhi",
      "city": "New Delhi",
      "country": "India",
      "pincode": "110001",
      "role": "admin",
      "profileImage": null,
      "createdAt": "2025-01-15T10:30:00",
      "updatedAt": "2025-01-15T10:30:00"
    },
    {
      "id": 2,
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "9876543210",
      "address": "123 Main Street",
      "state": "California",
      "city": "Los Angeles",
      "country": "USA",
      "pincode": "90001",
      "role": "user",
      "profileImage": null,
      "createdAt": "2025-01-15T11:00:00",
      "updatedAt": "2025-01-15T11:00:00"
    }
  ]
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Invalid token"
}
```

**Error Response (403):**
```json
{
  "success": false,
  "message": "Unauthorized. Admin access required."
}
```

**cURL Example:**
```bash
curl -X GET http://localhost:8080/api/users \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json"
```

---

### 5. Get User by ID

**Endpoint:** `GET /api/users/:id`

**Description:** Retrieve specific user details

**URL Parameters:**
- `id` (required): User ID

**Headers:**
```
Authorization: Bearer YOUR_ACCESS_TOKEN
Content-Type: application/json
```

**Success Response (200):**
```json
{
  "success": true,
  "data": {
    "id": 2,
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "9876543210",
    "address": "123 Main Street",
    "state": "California",
    "city": "Los Angeles",
    "country": "USA",
    "pincode": "90001",
    "role": "user",
    "profileImage": null,
    "createdAt": "2025-01-15T11:00:00",
    "updatedAt": "2025-01-15T11:00:00"
  }
}
```

**Error Response (404):**
```json
{
  "success": false,
  "message": "User not found"
}
```

**cURL Example:**
```bash
curl -X GET http://localhost:8080/api/users/2 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json"
```

---

### 6. Search Users (Admin Only)

**Endpoint:** `GET /api/users/search?keyword=VALUE`

**Description:** Search users by name, email, state, or city

**Query Parameters:**
- `keyword` (required): Search term

**Headers:**
```
Authorization: Bearer YOUR_ACCESS_TOKEN
Content-Type: application/json
```

**Success Response (200):**
```json
{
  "success": true,
  "data": [
    {
      "id": 2,
      "name": "John Doe",
      "email": "john@example.com",
      "phone": "9876543210",
      "address": "123 Main Street",
      "state": "California",
      "city": "Los Angeles",
      "country": "USA",
      "pincode": "90001",
      "role": "user",
      "profileImage": null,
      "createdAt": "2025-01-15T11:00:00",
      "updatedAt": "2025-01-15T11:00:00"
    }
  ]
}
```

**cURL Example:**
```bash
curl -X GET "http://localhost:8080/api/users/search?keyword=john" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json"
```

---

### 7. Update User

**Endpoint:** `PUT /api/users/:id`

**Description:** Update user information

**URL Parameters:**
- `id` (required): User ID

**Headers:**
```
Authorization: Bearer YOUR_ACCESS_TOKEN
Content-Type: application/json
```

**Request Body:**
```json
{
  "name": "John Updated",
  "phone": "9876543210",
  "address": "456 Oak Avenue",
  "state": "California",
  "city": "San Francisco",
  "country": "USA",
  "pincode": "94105"
}
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "User updated successfully"
}
```

**Error Response (400):**
```json
{
  "success": false,
  "message": "Invalid name"
}
```

**Validation Rules (same as registration):**
- All fields required except address
- Address: max 150 characters
- Name: 3-100 chars, alphabets and spaces only
- Phone: 10-15 digits
- Pincode: 4-10 digits

**cURL Example:**
```bash
curl -X PUT http://localhost:8080/api/users/2 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Updated",
    "phone": "9876543210",
    "address": "456 Oak Avenue",
    "state": "California",
    "city": "San Francisco",
    "country": "USA",
    "pincode": "94105"
  }'
```

---

### 8. Delete User (Admin Only)

**Endpoint:** `DELETE /api/users/:id`

**Description:** Delete a user account (Admin only)

**URL Parameters:**
- `id` (required): User ID

**Headers:**
```
Authorization: Bearer YOUR_ACCESS_TOKEN
Content-Type: application/json
```

**Success Response (200):**
```json
{
  "success": true,
  "message": "User deleted successfully"
}
```

**Error Response (401):**
```json
{
  "success": false,
  "message": "Invalid token"
}
```

**Error Response (403):**
```json
{
  "success": false,
  "message": "Unauthorized. Admin access required."
}
```

**cURL Example:**
```bash
curl -X DELETE http://localhost:8080/api/users/2 \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json"
```

---

## 🔐 Authentication & Authorization

### Token Structure

**Access Token:**
```json
{
  "sub": "2",           // User ID
  "email": "john@example.com",
  "role": "user",
  "iat": 1705334400,    // Issued at
  "exp": 1705338000     // Expires at (1 hour)
}
```

**Refresh Token:**
```json
{
  "sub": "2",           // User ID
  "email": "john@example.com",
  "iat": 1705334400,    // Issued at
  "exp": 1705939200     // Expires at (7 days)
}
```

### Authorization Levels

| Endpoint | Permission |
|----------|-----------|
| POST /api/auth/register | Public |
| POST /api/auth/login | Public |
| POST /api/auth/refresh | Public |
| GET /api/users | Admin |
| GET /api/users/:id | Authenticated User |
| PUT /api/users/:id | Authenticated User |
| DELETE /api/users/:id | Admin |
| GET /api/users/search | Admin |

---

## 📊 HTTP Status Codes

| Code | Status | Meaning |
|------|--------|---------|
| 200 | OK | Request successful |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Invalid input or validation error |
| 401 | Unauthorized | Missing or invalid authentication |
| 403 | Forbidden | Insufficient permissions |
| 404 | Not Found | Resource not found |
| 500 | Server Error | Internal server error |

---

## 🧪 Testing Workflow

### 1. Register a New User
```bash
# Request
POST /api/auth/register
{
  "name": "Test User",
  "email": "test@example.com",
  "phone": "9876543210",
  "password": "test@123",
  "state": "NY",
  "city": "New York",
  "country": "USA",
  "pincode": "10001"
}

# Response
{
  "success": true,
  "message": "User registered successfully",
  "userId": 10
}
```

### 2. Login as Admin
```bash
# Request
POST /api/auth/login
{
  "email": "admin@test.com",
  "password": "password123"
}

# Response (save tokens)
{
  "success": true,
  "message": "Login successful",
  "accessToken": "...",
  "refreshToken": "..."
}
```

### 3. Get All Users
```bash
# Request
GET /api/users
Header: Authorization: Bearer {accessToken}

# Response
{
  "success": true,
  "data": [...]
}
```

### 4. Update User
```bash
# Request
PUT /api/users/10
Header: Authorization: Bearer {accessToken}
{
  "name": "Updated Name",
  "phone": "9876543210",
  "state": "CA",
  "city": "Los Angeles",
  "country": "USA",
  "pincode": "90001"
}

# Response
{
  "success": true,
  "message": "User updated successfully"
}
```

### 5. Delete User
```bash
# Request
DELETE /api/users/10
Header: Authorization: Bearer {accessToken}

# Response
{
  "success": true,
  "message": "User deleted successfully"
}
```

---

## 🐛 Common Errors & Solutions

| Error | Cause | Solution |
|-------|-------|----------|
| "Invalid token" | Token expired or malformed | Get new token using refresh endpoint |
| "User not found" | Invalid user ID | Check user ID is correct |
| "Email already exists" | Email is duplicate | Use different email |
| "Unauthorized. Admin access required" | User not admin | Use admin account |
| "Connection refused" | Server not running | Start backend server |
| CORS error | Cross-origin request blocked | Ensure API URL is correct |

---

## 📝 Request/Response Examples

### Complete Login & Access Workflow

```bash
#!/bin/bash

# Step 1: Login
LOGIN_RESPONSE=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@test.com",
    "password": "password123"
  }')

# Extract token from response
ACCESS_TOKEN=$(echo $LOGIN_RESPONSE | grep -o '"accessToken":"[^"]*' | cut -d'"' -f4)

# Step 2: Get all users with token
curl -X GET http://localhost:8080/api/users \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json"

# Step 3: Search users
curl -X GET "http://localhost:8080/api/users/search?keyword=john" \
  -H "Authorization: Bearer $ACCESS_TOKEN"

# Step 4: Update user
curl -X PUT http://localhost:8080/api/users/2 \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Updated John",
    "phone": "9876543210",
    "state": "CA",
    "city": "LA",
    "country": "USA",
    "pincode": "90001"
  }'
```

---

## 📚 Additional Resources

- **Postman Collection**: Import `Postman_Collection.json` for ready-to-use API requests
- **Database Documentation**: See `DATABASE_DOCUMENTATION.md`
- **Architecture Diagram**: See `ARCHITECTURE.md`
- **Setup Guide**: See `SETUP_GUIDE.md`

---

**API Documentation Complete!**

For more information, refer to the README.md or source code comments.
