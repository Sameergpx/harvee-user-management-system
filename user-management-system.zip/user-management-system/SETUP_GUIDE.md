# User Management System - Setup Guide

## 🚀 Quick Start (5 minutes)

### Prerequisites Check
```bash
# Check Java Version
java -version    # Should be 11 or higher

# Check Maven Version
mvn -version     # Should be 3.6 or higher

# Check MySQL
mysql --version  # Should be 8.0 or higher
```

---

## 📋 Step-by-Step Installation

### STEP 1: Database Setup (MySQL)

1. **Start MySQL Service**
   - On Windows: Open Services and start MySQL
   - On Mac/Linux: `sudo systemctl start mysql`

2. **Connect to MySQL**
   ```bash
   mysql -u root -p
   ```

3. **Create Database**
   ```sql
   CREATE DATABASE user_management_db;
   USE user_management_db;
   ```

4. **Import Schema**
   ```sql
   CREATE TABLE users (
       id INT AUTO_INCREMENT PRIMARY KEY,
       name VARCHAR(100) NOT NULL,
       email VARCHAR(100) UNIQUE NOT NULL,
       phone VARCHAR(15) NOT NULL,
       password VARCHAR(255) NOT NULL,
       profile_image VARCHAR(255),
       address VARCHAR(150),
       state VARCHAR(50) NOT NULL,
       city VARCHAR(50) NOT NULL,
       country VARCHAR(50) NOT NULL,
       pincode VARCHAR(10) NOT NULL,
       role ENUM('user', 'admin') DEFAULT 'user',
       created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
   );

   INSERT INTO users (name, email, phone, password, state, city, country, pincode, role) 
   VALUES ('Admin User', 'admin@test.com', '9876543210', '$2a$10$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lm', 'Delhi', 'New Delhi', 'India', '110001', 'admin');
   ```

5. **Verify**
   ```sql
   SELECT * FROM users;
   ```

✅ **Database is ready!**

---

### STEP 2: Configure Backend

1. **Navigate to backend folder**
   ```bash
   cd backend
   ```

2. **Update Database Configuration**
   
   Open: `src/main/java/com/usermanagement/util/DBConnection.java`
   
   Update these lines:
   ```java
   private static final String DB_URL = "jdbc:mysql://localhost:3306/user_management_db";
   private static final String DB_USER = "root";
   private static final String DB_PASSWORD = "YOUR_MYSQL_PASSWORD";  // Change this
   ```

3. **Update Security Configuration (Optional)**
   
   Open: `src/main/java/com/usermanagement/util/SecurityUtils.java`
   
   For production, change:
   ```java
   private static final String SECRET_KEY = "change-this-to-secure-key";
   ```

✅ **Configuration complete!**

---

### STEP 3: Build Backend with Maven

1. **Navigate to backend**
   ```bash
   cd backend
   ```

2. **Clean and Build**
   ```bash
   mvn clean install
   ```

3. **Create Executable JAR**
   ```bash
   mvn package
   ```

   You should see: `BUILD SUCCESS`

4. **Verify JAR Created**
   ```bash
   ls target/
   # You should see: user-management-system-1.0.0-jar-with-dependencies.jar
   ```

✅ **Backend built successfully!**

---

### STEP 4: Run Backend Server

1. **Navigate to backend directory**
   ```bash
   cd backend
   ```

2. **Start the Server**
   ```bash
   java -jar target/user-management-system-1.0.0-jar-with-dependencies.jar
   ```

   You should see:
   ```
   Server started on port 8080
   Open http://localhost:8080 in your browser
   ```

3. **Verify Server is Running**
   
   In another terminal:
   ```bash
   curl http://localhost:8080
   ```

✅ **Backend is running!**

---

### STEP 5: Access Application

1. **Open Browser**
   - URL: `http://localhost:8080`

2. **Test Registration**
   - Click "Register"
   - Fill form with test data
   - Submit

3. **Test Login**
   - Click "Login"
   - Use admin credentials:
     - Email: `admin@test.com`
     - Password: `password123`
   - Should redirect to admin dashboard

4. **Test Admin Features**
   - View all users
   - Search users
   - Edit user details
   - Delete users
   - View own profile

✅ **Application is working!**

---

## 🔌 API Testing with Postman

### 1. Download Postman
- Visit: https://www.postman.com/downloads/

### 2. Create Collection

**Test Register Endpoint**
- Method: POST
- URL: `http://localhost:8080/api/auth/register`
- Headers: `Content-Type: application/json`
- Body (JSON):
```json
{
  "name": "Test User",
  "email": "test@example.com",
  "phone": "9876543210",
  "password": "password123",
  "address": "123 Test Street",
  "state": "California",
  "city": "Los Angeles",
  "country": "USA",
  "pincode": "90001"
}
```

**Test Login Endpoint**
- Method: POST
- URL: `http://localhost:8080/api/auth/login`
- Headers: `Content-Type: application/json`
- Body (JSON):
```json
{
  "email": "admin@test.com",
  "password": "password123"
}
```

**Test Get All Users (Admin Only)**
- Method: GET
- URL: `http://localhost:8080/api/users`
- Headers: 
  - `Content-Type: application/json`
  - `Authorization: Bearer YOUR_ACCESS_TOKEN`

---

## 🐛 Troubleshooting

### Issue 1: MySQL Connection Failed

**Error:** `Connection refused` or `Access denied`

**Solutions:**
1. Verify MySQL is running
2. Check username and password in DBConnection.java
3. Verify database exists: `SHOW DATABASES;`

```bash
# Start MySQL Service
# Windows:
net start MySQL80

# Mac:
brew services start mysql

# Linux:
sudo systemctl start mysql
```

### Issue 2: Port 8080 Already in Use

**Error:** `Address already in use`

**Solutions:**
1. Change port in Main.java
2. Or kill the process using port 8080

```bash
# Windows - Find process on port 8080
netstat -ano | findstr :8080

# Kill the process
taskkill /PID <PID> /F

# Mac/Linux
sudo lsof -i :8080
kill -9 <PID>
```

### Issue 3: Maven Build Failed

**Error:** `Build Failure`

**Solutions:**
1. Ensure Java 11+ is installed
2. Clear Maven cache: `mvn clean`
3. Check internet connection for downloading dependencies

### Issue 4: CORS Errors in Console

**Error:** `Access to XMLHttpRequest blocked by CORS`

**Solution:** CORS is already configured. Check:
1. Browser console for actual error
2. API endpoint URL is correct
3. Server is running

### Issue 5: JWT Token Expired

**Error:** `Invalid token` after 1 hour

**Solution:** Use refresh endpoint:
```bash
POST /api/auth/refresh
Body: {
  "refreshToken": "YOUR_REFRESH_TOKEN"
}
```

### Issue 6: Blank Dashboard or 404 Errors

**Error:** Frontend files not loading

**Solutions:**
1. Verify frontend files exist in correct location
2. Check file paths in Main.java
3. Ensure server is serving static files

---

## 📊 Database Verification

### Check Database Structure
```sql
USE user_management_db;
DESCRIBE users;
```

### Check Admin User
```sql
SELECT * FROM users WHERE email = 'admin@test.com';
```

### Check All Users
```sql
SELECT id, name, email, role FROM users;
```

### Delete Test Users
```sql
DELETE FROM users WHERE email = 'test@example.com';
```

---

## 🚀 Production Deployment

### Before Deploying

1. **Change Security Settings**
   - Update JWT SECRET_KEY
   - Use strong database password
   - Enable HTTPS

2. **Update Configuration**
   ```java
   // Production settings
   DB_PASSWORD = secure_password
   SECRET_KEY = generate_random_key
   ```

3. **Build Final JAR**
   ```bash
   mvn clean package -DskipTests
   ```

### Deploy with Docker (Optional)

1. **Create Dockerfile**
   ```dockerfile
   FROM openjdk:11-jre-slim
   WORKDIR /app
   COPY backend/target/user-management-system-1.0.0-jar-with-dependencies.jar app.jar
   COPY frontend/ frontend/
   EXPOSE 8080
   CMD ["java", "-jar", "app.jar"]
   ```

2. **Build Image**
   ```bash
   docker build -t user-management-system:1.0 .
   ```

3. **Run Container**
   ```bash
   docker run -p 8080:8080 \
     -e DB_URL=jdbc:mysql://mysql-server:3306/user_management_db \
     -e DB_USER=root \
     -e DB_PASSWORD=your_password \
     user-management-system:1.0
   ```

### Deploy to Cloud (AWS/Azure/GCP)

1. Create EC2 instance (or similar)
2. Install Java and MySQL
3. Upload JAR file
4. Run application
5. Configure DNS and security groups

---

## 📝 Development Tips

### Enable Debug Logging
```java
// In Main.java or any class
System.out.println("Debug: " + variable);
```

### Test Locally with cURL
```bash
# Register
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{...}'

# Login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"password123"}'

# Get Users
curl -X GET http://localhost:8080/api/users \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Hot Reload Development
1. Use an IDE (IntelliJ, Eclipse, VS Code)
2. Set up run configuration
3. Use debug mode with breakpoints

---

## ✅ Verification Checklist

- [ ] MySQL installed and running
- [ ] Database `user_management_db` created
- [ ] Admin user inserted
- [ ] Java 11+ installed
- [ ] Maven installed and working
- [ ] Backend built successfully
- [ ] Server running on port 8080
- [ ] Can access http://localhost:8080
- [ ] Can register new user
- [ ] Can login with admin credentials
- [ ] Can view admin dashboard
- [ ] Can search and manage users

---

## 📞 Support & Documentation

- **README.md** - Project overview
- **ARCHITECTURE.md** - System architecture diagrams
- **API Documentation** - Available in code comments
- **Database Schema** - In database/schema.sql

---

**🎉 Setup Complete! Happy Coding!**
