# User Management System

A comprehensive Full-Stack User Management System built with **Java** backend, **MySQL** database, and **HTML/CSS/JavaScript** frontend with Bootstrap.

## 🎯 Features

### Core Functionality
- ✅ **User Registration** - Secure registration with validation
- ✅ **User Login** - JWT token-based authentication
- ✅ **JWT Authentication** - Access & Refresh tokens
- ✅ **CRUD Operations** - Create, Read, Update, Delete users
- ✅ **Admin Panel** - Web-based dashboard for administrators
- ✅ **Role-Based Access** - User and Admin roles
- ✅ **Advanced Search** - Search & filter by name, email, state, city
- ✅ **Password Hashing** - BCrypt encryption
- ✅ **Input Validation** - Backend & frontend validation
- ✅ **Image Upload Support** - Profile image upload
- ✅ **CORS Support** - Cross-Origin Resource Sharing

### Technology Stack
- **Backend:** Java 11+
- **Server:** Java HTTP Server (com.sun.net.httpserver)
- **Database:** MySQL 8.0+
- **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
- **UI Framework:** Bootstrap 5.3
- **Authentication:** JWT (Java-JWT)
- **Password Hashing:** BCrypt (jBCrypt)
- **Build Tool:** Maven 3.6+

## 📋 Project Structure

```
user-management-system/
├── backend/
│   ├── src/main/java/com/usermanagement/
│   │   ├── Main.java                    # HTTP Server Entry Point
│   │   ├── model/
│   │   │   └── User.java               # User Entity
│   │   ├── dao/
│   │   │   └── UserDAO.java            # Data Access Object
│   │   ├── service/
│   │   │   └── UserService.java        # Business Logic
│   │   ├── controller/
│   │   │   ├── AuthController.java     # Authentication APIs
│   │   │   └── UserController.java     # User Management APIs
│   │   └── util/
│   │       ├── DBConnection.java       # Database Connection
│   │       ├── SecurityUtils.java      # JWT & Password Utils
│   │       └── ValidationUtils.java    # Input Validation
│   ├── src/main/resources/
│   └── pom.xml                          # Maven Configuration
│
├── frontend/
│   ├── index.html                       # Home Page
│   ├── register.html                    # Registration Page
│   ├── login.html                       # Login Page
│   ├── dashboard.html                   # Admin Dashboard
│   ├── css/
│   │   └── style.css                   # Styling
│   └── js/
│       ├── register.js                 # Register Script
│       ├── login.js                    # Login Script
│       └── dashboard.js                # Dashboard Script
│
├── database/
│   └── schema.sql                       # MySQL Database Schema
│
├── .gitignore
└── README.md
```

## 🚀 Installation & Setup

### Prerequisites
- **Java 11 or higher** - [Download JDK](https://adoptopenjdk.net/)
- **MySQL 8.0 or higher** - [Download MySQL](https://www.mysql.com/downloads/)
- **Maven 3.6+** - [Download Maven](https://maven.apache.org/download.cgi)
- **Git** (Optional)

### Step 1: Database Setup

1. Open MySQL Command Line or MySQL Workbench
2. Run the following commands:

```sql
CREATE DATABASE user_management_db;
USE user_management_db;
```

3. Import the schema from `database/schema.sql`:

```bash
mysql -u root -p user_management_db < database/schema.sql
```

Or copy-paste the contents of `database/schema.sql` into MySQL client.

### Step 2: Update Database Configuration

Edit `backend/src/main/java/com/usermanagement/util/DBConnection.java`:

```java
private static final String DB_URL = "jdbc:mysql://localhost:3306/user_management_db";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = ""; // Enter your MySQL password
```

### Step 3: Build Backend

Navigate to the backend directory and build with Maven:

```bash
cd backend
mvn clean install
mvn package
```

### Step 4: Run Backend Server

```bash
cd backend
java -jar target/user-management-system-1.0.0-jar-with-dependencies.jar
```

The server will start on **http://localhost:8080**

### Step 5: Access Frontend

Open your browser and navigate to:
```
http://localhost:8080
```

## 📱 API Endpoints

### Authentication APIs

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login user |
| POST | `/api/auth/refresh` | Refresh access token |

### User APIs (Requires JWT Token)

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| GET | `/api/users` | Get all users | Admin |
| GET | `/api/users/:id` | Get user by ID | Authenticated |
| PUT | `/api/users/:id` | Update user | Authenticated |
| DELETE | `/api/users/:id` | Delete user | Admin |
| GET | `/api/users/search?keyword=...` | Search users | Admin |

### Request Examples

#### Register User
```json
POST /api/auth/register
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "9876543210",
  "password": "password123",
  "address": "123 Main Street",
  "state": "California",
  "city": "Los Angeles",
  "country": "USA",
  "pincode": "90001"
}
```

#### Login User
```json
POST /api/auth/login
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

#### Update User
```json
PUT /api/users/1
Content-Type: application/json
Authorization: Bearer YOUR_ACCESS_TOKEN

{
  "name": "John Updated",
  "phone": "9876543210",
  "address": "456 Oak Avenue",
  "state": "California",
  "city": "San Francisco",
  "country": "USA",
  "pincode": "94105"
}
```

## 🔐 Authentication & Security

### JWT Token Structure

**Access Token:**
- Expiry: 1 hour
- Contains: User ID, Email, Role

**Refresh Token:**
- Expiry: 7 days
- Used to generate new access tokens

### Password Policy
- Minimum 6 characters
- Must contain at least one number
- Hashed using BCrypt algorithm

### Input Validation

**Name:**
- Minimum 3 characters
- Alphabets and spaces only

**Email:**
- Valid email format
- Unique in database

**Phone:**
- 10-15 digits

**Pincode:**
- 4-10 digits

**Address:**
- Maximum 150 characters (optional)

**Profile Image:**
- JPG/PNG only
- Maximum 2MB

## 👤 Demo Account

After setting up the database, an admin account is automatically created:

```
Email: admin@test.com
Password: password123
```

## 📊 Database Schema

### Users Table
```sql
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15) NOT NULL,
    password VARCHAR(255) NOT NULL,
    profile_image VARCHAR(255),
    address VARCHAR(150),
    state VARCHAR(50) NOT NULL,
    city VARCHAR(50) NOT NULL,
    country VARCHAR(50) NOT NULL,
    pincode VARCHAR(10) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## 🎨 Frontend Pages

### 1. **Home Page (index.html)**
- Welcome message
- Quick links to login/register
- Features overview

### 2. **Registration (register.html)**
- User registration form
- Client-side validation
- Real-time error messages

### 3. **Login (login.html)**
- Email & password login
- Demo credentials display
- Token storage

### 4. **Admin Dashboard (dashboard.html)**
- Dashboard overview with statistics
- User management table
- Search & filter functionality
- Edit & delete operations
- User details view modal

## 🔧 Configuration

### Change JWT Secret Key

Edit `backend/src/main/java/com/usermanagement/util/SecurityUtils.java`:

```java
private static final String SECRET_KEY = "your-secret-key-change-this-in-production";
```

### Change Server Port

Edit `backend/src/main/java/com/usermanagement/Main.java`:

```java
private static final int PORT = 8080; // Change to your desired port
```

## 🧪 Testing

### Using Postman

1. Download [Postman](https://www.postman.com/downloads/)
2. Import the collection from `postman_collection.json` (if available)
3. Test each endpoint

### Manual Testing

1. **Register User**
   - Open http://localhost:8080/register.html
   - Fill the form and submit

2. **Login**
   - Open http://localhost:8080/login.html
   - Use admin@test.com / password123

3. **Admin Dashboard**
   - Access admin panel to view, search, edit, delete users

## 📝 Code Quality

### Best Practices Implemented
- ✅ MVC Architecture (Model-View-Controller)
- ✅ Separation of Concerns (DAO, Service, Controller)
- ✅ Input Validation (Client & Server)
- ✅ Error Handling & Logging
- ✅ Security (JWT, Password Hashing, CORS)
- ✅ RESTful API Design
- ✅ Responsive UI Design
- ✅ Code Comments & Documentation

## 🐳 Docker Support (Optional)

### Create Dockerfile

```dockerfile
FROM openjdk:11-jre-slim

WORKDIR /app

COPY backend/target/user-management-system-1.0.0-jar-with-dependencies.jar app.jar
COPY frontend/ frontend/

EXPOSE 8080

CMD ["java", "-jar", "app.jar"]
```

### Build & Run
```bash
docker build -t user-management-system .
docker run -p 8080:8080 user-management-system
```

## 📚 Additional Resources

- [JWT Documentation](https://jwt.io/)
- [Bootstrap Documentation](https://getbootstrap.com/docs/)
- [MySQL Documentation](https://dev.mysql.com/doc/)
- [Java Servlet API](https://docs.oracle.com/javaee/7/api/javax/servlet/http/package-summary.html)

## 🤝 Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 👨‍💻 Author

**Your Name**

## 🙏 Acknowledgments

- Bootstrap for responsive UI framework
- JWT for secure token-based authentication
- BCrypt for secure password hashing
- MySQL for reliable database

## 📞 Support

For support, email support@example.com or open an issue in the repository.

---

**Happy Coding! 🚀**

---

## Troubleshooting

### Issue: "Connection refused" error
**Solution:** Make sure MySQL is running and database credentials are correct in DBConnection.java

### Issue: "Port 8080 already in use"
**Solution:** Change PORT in Main.java or kill the process using port 8080

### Issue: CORS errors in browser console
**Solution:** CORS headers are already configured in Main.java APIHandler class

### Issue: JWT token expired
**Solution:** Use the refresh token endpoint to get a new access token

### Issue: CSS/JS files not loading
**Solution:** Make sure file paths are correct and server is serving static files properly
