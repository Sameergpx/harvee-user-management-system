# User Management System - Architecture Diagram

## System Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                          CLIENT (Frontend)                          │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐               │
│  │ register.html│  │  login.html  │  │dashboard.html│               │
│  └──────────────┘  └──────────────┘  └──────────────┘               │
│         │                 │                  │                       │
│         └─────────────────┼──────────────────┘                       │
│                           │                                         │
│                    ┌──────▼───────┐                                │
│                    │ JavaScript   │                                │
│                    │ (CORS API    │                                │
│                    │  Calls)      │                                │
│                    └──────┬───────┘                                │
│                    Bootstrap 5.3 UI                               │
│                           │                                         │
└───────────────────────────┼─────────────────────────────────────────┘
                            │ HTTP REST API
                            │ (JSON/Authorization)
                            │
┌───────────────────────────▼─────────────────────────────────────────┐
│                   BACKEND (Java Server)                             │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │              HTTP Server (Port 8080)                         │  │
│  │  - StaticFileHandler (HTML/CSS/JS)                          │  │
│  │  - APIHandler (REST Endpoints)                              │  │
│  └──────────────────────────────────────────────────────────────┘  │
│                           │                                        │
│                ┌──────────┴──────────┐                            │
│                │                     │                            │
│         ┌──────▼───────┐      ┌──────▼───────┐                   │
│         │AuthController│      │UserController│                   │
│         │              │      │              │                   │
│         │ - register() │      │ - getAll()   │                   │
│         │ - login()    │      │ - getById()  │                   │
│         │ - refresh()  │      │ - update()   │                   │
│         └──────┬───────┘      │ - delete()   │                   │
│                │              │ - search()   │                   │
│                │              └──────┬───────┘                   │
│         ┌──────▼────────────────────▼──────────┐                │
│         │         UserService                  │                │
│         │                                      │                │
│         │ - registerUser()                     │                │
│         │ - loginUser()                        │                │
│         │ - getAllUsers()                      │                │
│         │ - updateUser()                       │                │
│         │ - deleteUser()                       │                │
│         │ - searchUsers()                      │                │
│         └──────┬─────────────────────────────┬─┘                │
│                │                             │                  │
│         ┌──────▼──────┐            ┌────────▼────────┐         │
│         │ Validation  │            │  Security       │         │
│         │ Utils       │            │  Utils          │         │
│         │             │            │                 │         │
│         │- isValid... │            │- hashPassword() │         │
│         │  Name       │            │- verifyPassword │         │
│         │- isValid... │            │- generateToken()│         │
│         │  Email      │            │- verifyToken()  │         │
│         │- isValid... │            │                 │         │
│         │  Phone      │            │JWT: auth0-jwt   │         │
│         │- etc...     │            │BCrypt: jbcrypt  │         │
│         └──────┬──────┘            └────────┬────────┘         │
│                │                           │                   │
│         ┌──────▼───────────────────────────▼──────┐             │
│         │          UserDAO (Database)             │             │
│         │                                         │             │
│         │ - createUser()                          │             │
│         │ - getUserByEmail()                      │             │
│         │ - getUserById()                         │             │
│         │ - getAllUsers()                         │             │
│         │ - updateUser()                          │             │
│         │ - deleteUser()                          │             │
│         │ - emailExists()                         │             │
│         │ - searchUsers()                         │             │
│         │                                         │             │
│         └──────┬──────────────────────────────────┘             │
│                │                                               │
│         ┌──────▼──────────────────────────────────┐             │
│         │      DBConnection (MySQL Driver)       │             │
│         │                                        │             │
│         │ - getConnection()                      │             │
│         │ - closeConnection()                    │             │
│         └──────┬──────────────────────────────────┘             │
│                │                                               │
└────────────────┼───────────────────────────────────────────────┘
                 │ JDBC Connection
                 │ (SQL Queries)
                 │
┌────────────────▼───────────────────────────────────────────────┐
│                  DATABASE (MySQL)                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                │
│  Database: user_management_db                                 │
│                                                                │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │                    USERS TABLE                           │ │
│  ├──────────────────────────────────────────────────────────┤ │
│  │ id (PK)       │ email (UNIQUE)  │ role                  │ │
│  │ name          │ phone           │ created_at            │ │
│  │ password(hash)│ profileImage    │ updated_at            │ │
│  │ address       │ state           │ country               │ │
│  │ city          │ pincode         │                       │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

## Data Flow Diagram

### User Registration Flow
```
┌─────────────┐
│ User Form   │
└──────┬──────┘
       │ Submit (JSON)
       ▼
┌─────────────────────────────┐
│ Frontend Validation         │
│ (register.js)               │
└──────┬──────────────────────┘
       │ POST /api/auth/register
       ▼
┌─────────────────────────────────┐
│ Backend Validation              │
│ (ValidationUtils)               │
└──────┬──────────────────────────┘
       │ Valid
       ▼
┌─────────────────────────────────┐
│ Password Hashing                │
│ (SecurityUtils - BCrypt)        │
└──────┬──────────────────────────┘
       │ Hashed Password
       ▼
┌─────────────────────────────────┐
│ Save to Database                │
│ (UserDAO.createUser())          │
└──────┬──────────────────────────┘
       │ Success
       ▼
┌─────────────────────────────┐
│ Return Success Response     │
│ (JSON)                      │
└─────────────────────────────┘
```

### User Login Flow
```
┌──────────────────┐
│ Login Form       │
│ email + password │
└────────┬─────────┘
         │ POST /api/auth/login
         ▼
┌──────────────────────────────────┐
│ Find User by Email               │
│ (UserDAO.getUserByEmail())       │
└────────┬─────────────────────────┘
         │ User Found
         ▼
┌──────────────────────────────────┐
│ Verify Password                  │
│ (SecurityUtils.verifyPassword()) │
└────────┬─────────────────────────┘
         │ Password Match
         ▼
┌──────────────────────────────────────────┐
│ Generate JWT Tokens                      │
│ - Access Token (1 hour)                  │
│ - Refresh Token (7 days)                 │
└────────┬─────────────────────────────────┘
         │ Tokens Generated
         ▼
┌────────────────────────────────────┐
│ Return Response with Tokens        │
│ userId, email, role, tokens        │
└────────────────────────────────────┘
         │ Store in localStorage
         ▼
┌────────────────────────────────────┐
│ Access Dashboard                   │
│ (dashboard.html)                   │
└────────────────────────────────────┘
```

### Admin Operations Flow
```
┌──────────────────────────────┐
│ Admin Dashboard              │
│ (dashboard.html)             │
└────────┬─────────────────────┘
         │ Bearer Token (Authorization)
         ▼
┌──────────────────────────────────────┐
│ Verify JWT Token                     │
│ (SecurityUtils.verifyToken())        │
└────────┬─────────────────────────────┘
         │ Token Valid & Admin Role
         ▼
┌──────────────────────────────────────┐
│ Execute Operation                    │
│ - GET /api/users (Get All)           │
│ - GET /api/users/:id (Get One)       │
│ - PUT /api/users/:id (Update)        │
│ - DELETE /api/users/:id (Delete)     │
│ - GET /api/users/search (Search)     │
└────────┬─────────────────────────────┘
         │ Database Operation
         ▼
┌──────────────────────────────────────┐
│ Return Response                      │
│ (JSON Data or Success Message)       │
└──────────────────────────────────────┘
```

## Security Architecture

```
┌─────────────────────────────────────────────────────────┐
│              Security Layers                            │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  1. CLIENT SIDE                                         │
│     ├─ Input Validation (JavaScript)                    │
│     ├─ HTTPS Recommended                                │
│     └─ Secure Token Storage (localStorage)              │
│                                                         │
│  2. TRANSMISSION                                        │
│     ├─ CORS Configuration                               │
│     ├─ Content-Type Validation                          │
│     └─ Authorization Header (JWT)                       │
│                                                         │
│  3. SERVER SIDE                                         │
│     ├─ Input Validation (Backend)                       │
│     ├─ JWT Token Verification                           │
│     ├─ Role-Based Access Control                        │
│     └─ Error Handling (No Sensitive Data)               │
│                                                         │
│  4. DATABASE                                            │
│     ├─ Password Hashing (BCrypt)                        │
│     ├─ Prepared Statements (SQL Injection Prevention)   │
│     ├─ Unique Constraints (Email)                       │
│     └─ Timestamps (Audit Trail)                         │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Technology Stack Architecture

```
┌────────────────────────────────────────┐
│  PRESENTATION LAYER                    │
├────────────────────────────────────────┤
│  HTML5 | CSS3 | JavaScript (Vanilla)   │
│  Bootstrap 5.3 | Responsive Design     │
└────────────────────────────────────────┘
                   │
┌────────────────────────────────────────┐
│  API LAYER                             │
├────────────────────────────────────────┤
│  REST API (JSON)                       │
│  HTTP Server (Java)                    │
│  CORS Support                          │
│  JWT Authentication                    │
└────────────────────────────────────────┘
                   │
┌────────────────────────────────────────┐
│  BUSINESS LOGIC LAYER                  │
├────────────────────────────────────────┤
│  UserService                           │
│  Validation                            │
│  Security (Password, JWT)              │
└────────────────────────────────────────┘
                   │
┌────────────────────────────────────────┐
│  DATA ACCESS LAYER (DAO)               │
├────────────────────────────────────────┤
│  UserDAO                               │
│  Database Queries                      │
│  JDBC Connection Management            │
└────────────────────────────────────────┘
                   │
┌────────────────────────────────────────┐
│  DATABASE LAYER                        │
├────────────────────────────────────────┤
│  MySQL 8.0+                            │
│  user_management_db                    │
│  Users Table                           │
└────────────────────────────────────────┘
```

## Deployment Architecture

```
┌─────────────────────────────────────────────┐
│          Production Environment             │
├─────────────────────────────────────────────┤
│                                             │
│  ┌──────────────────────────────────────┐  │
│  │  Docker Container (Optional)         │  │
│  │  ┌────────────────────────────────┐  │  │
│  │  │ Java 11 JRE                    │  │  │
│  │  ├────────────────────────────────┤  │  │
│  │  │ User Management System JAR     │  │  │
│  │  │ Port 8080 (Internal)           │  │  │
│  │  ├────────────────────────────────┤  │  │
│  │  │ Frontend Files                 │  │  │
│  │  └────────────────────────────────┘  │  │
│  └──────────────────────────────────────┘  │
│           │                                 │
│  Port Mapping: 8080 → 8080                 │
│           │                                 │
│  ┌────────▼──────────────────────────────┐ │
│  │  nginx (Reverse Proxy)                │ │
│  │  ├─ Load Balancing                    │ │
│  │  ├─ SSL/TLS Termination               │ │
│  │  └─ Static File Serving               │ │
│  └────────┬──────────────────────────────┘ │
│           │                                 │
│           ▼                                 │
│       Port 80/443 (Public)                 │
│                                             │
└─────────────────────────────────────────────┘
```

---

**Note:** This is a monolithic architecture suitable for small to medium-sized applications. For enterprise deployments, consider microservices architecture.
