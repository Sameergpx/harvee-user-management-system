# ⚡ Quick Reference Card

## 🚀 Start Server (1 Command)
```bash
java -jar backend/target/user-management-system-1.0.0-jar-with-dependencies.jar
```

## 🌐 Access Application
```
http://localhost:8080
```

## 📝 Demo Account
```
Email: admin@test.com
Password: password123
```

---

## 📚 Quick Links to Files

### Documentation
| File | Purpose |
|------|---------|
| README.md | Overview & Features |
| SETUP_GUIDE.md | Installation Steps |
| API_DOCUMENTATION.md | API Reference |
| DATABASE_DOCUMENTATION.md | Database Schema |
| ARCHITECTURE.md | System Design |

### Source Code
| Path | Purpose |
|------|---------|
| backend/src/main/java/com/usermanagement/ | Java Source |
| frontend/ | Frontend Files |
| database/schema.sql | Database Schema |
| backend/pom.xml | Maven Config |

### Configuration
| File | Config |
|------|--------|
| backend/src/.../DBConnection.java | Database Connection |
| backend/src/.../SecurityUtils.java | JWT Secret Key |
| backend/src/main/java/com/usermanagement/Main.java | Server Port |

---

## 🔧 Common Commands

### Build Backend
```bash
cd backend
mvn clean install
mvn package
```

### Database Setup
```bash
mysql -u root -p < database/schema.sql
```

### Run Tests (Postman)
```bash
Import: Postman_Collection.json
URL: http://localhost:8080
```

---

## 📡 API Endpoints

### Auth
- `POST /api/auth/register` - Register
- `POST /api/auth/login` - Login
- `POST /api/auth/refresh` - Refresh Token

### Users
- `GET /api/users` - All Users (Admin)
- `GET /api/users/:id` - Get User
- `PUT /api/users/:id` - Update
- `DELETE /api/users/:id` - Delete (Admin)
- `GET /api/users/search?keyword=X` - Search (Admin)

---

## 🔑 Default Credentials

```
Username: admin@test.com
Password: password123
Role: Admin
```

---

## ⏱️ Token Expiry

- **Access Token:** 1 hour
- **Refresh Token:** 7 days

---

## 📊 Key Validation Rules

| Field | Rule |
|-------|------|
| Name | 3-100 chars, letters only |
| Email | Valid format, unique |
| Phone | 10-15 digits |
| Password | 6+ chars with number |
| Pincode | 4-10 digits |

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| Port 8080 in use | Change PORT in Main.java |
| DB Connection Error | Check DBConnection.java settings |
| Build Failed | Run `mvn clean` |
| CORS Error | Check API URL |

---

## 📋 Directory Structure

```
user-management-system/
├── backend/             # Java Backend
├── frontend/            # HTML/CSS/JS
├── database/            # SQL Schema
├── README.md            # Overview
├── SETUP_GUIDE.md       # Installation
├── API_DOCUMENTATION.md # APIs
└── ...                  # Other docs
```

---

## ✅ Pre-Launch Checklist

- [ ] MySQL running
- [ ] Database created
- [ ] DBConnection.java updated
- [ ] Backend built (mvn package)
- [ ] Server started
- [ ] Browser at http://localhost:8080
- [ ] Can register user
- [ ] Can login
- [ ] Dashboard works

---

## 🎯 Next Steps

1. **Review:** Read README.md
2. **Setup:** Follow SETUP_GUIDE.md
3. **Build:** Run maven commands
4. **Test:** Use Postman collection
5. **Deploy:** Push to GitHub/Server

---

## 📞 Quick Help

**Documentation Files:**
- Setup Issues → SETUP_GUIDE.md
- API Usage → API_DOCUMENTATION.md
- Database → DATABASE_DOCUMENTATION.md
- Architecture → ARCHITECTURE.md

**Code Comments:**
- Most classes have detailed comments
- Check source files for implementation details

---

## 🎓 Key Technologies

- **Java 11+**
- **MySQL 8.0+**
- **JWT (Java-JWT)**
- **BCrypt**
- **Bootstrap 5.3**
- **HTML5 + CSS3**
- **Vanilla JavaScript**

---

## 🔐 Security Notes

- Passwords: BCrypt hashed
- Tokens: JWT signed
- CORS: Enabled
- SQL: Prepared statements
- Validation: Client + Server

---

## 💾 Database Info

**Database:** user_management_db
**Table:** users
**Records:** 1 admin account included

---

**Everything is ready! Happy coding! 🚀**
